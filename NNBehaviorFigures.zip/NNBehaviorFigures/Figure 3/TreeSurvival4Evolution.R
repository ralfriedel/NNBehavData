#Tree investigation using regression depicting evolution of stable nodes
#through training

# references: 
# https://rviews.rstudio.com/2017/09/25/survival-analysis-with-r/ 
# and
# https://www.rdocumentation.org/packages/ggbio/versions/1.20.1/topics/autoplot

library('tidyverse')
library('broom')
library('survival')
library('rms')
library('ranger')
library('ggfortify')

LAYER <- 'theone'

#tree # stable nodes (AOV on num stable nodes and factors as below)----
df <- read_csv(paste("D:\\Dev\\ThesisPy\\resultlog\\csv\\tree\\",
                     LAYER,"\\decTreeAnalysisLabelPiv.csv",
                     sep=''))
df <- df %>%
  mutate(ds = replace(ds, toupper(ds) == 'M0', 'CT')) %>%   
  mutate(ds = replace(ds, toupper(ds) == 'HW', 'PR'))

df <- df %>% select(model, ds, repl, lbl, nodelbl, rankstab) %>% 
  filter(!ds == 'CT') #not using the contrived data set

#doing the survival analysis
#1. Creating the analysis file:
#redefining column names to something more in line w/ survival analysis
epochs <- 151
df2 <- df %>% 
  mutate(node = nodelbl, 
         status = ifelse(rankstab == 1, 0, 1),
         time = epochs - rankstab) %>% 
  select(model, ds, repl, status, node, time)

#2. aov framework----
#doing the analysis for all data set to show that models are
#the strongest factor (need to use Cox for this). do not use repl as a factor

#using rms package
#https://stats.stackexchange.com/questions/119790/difference-in-chi-squared-calculated-by-anova-from-cph-and-coxph
crms <- cph(Surv(time, status) ~ model + ds, data = df2)
anova(crms)

#using survival package
cox <- coxph(Surv(time, status) ~ model + ds, data = df2)
summary(cox)
anova(cox)

#3. Using other approaches (KM)----
#Now that model is shown to be the strongest factor (highest z-score), further explore it
#by showing the plots by model. Use KM and Trees as methods and compare both,
#showing them to generate similar findings, thus more strongly making the point.

#need to split data and do this for each model
#no need to do this for any of the other factors

#3.1 Kaplan-Meier analysis----
#CNN and DNN (use for model comparisons)
km <- with(df2, Surv(time, status))
km_fit <- survfit(Surv(time, status) ~ 1, data=df2)
#print the estimates for 1, 5, 10 and 15 days, and then every 15 epochs thereafter
summary(km_fit, times = c(1, 5, 10, 15*(1:10)))
autoplot(km_fit, xlab = "Epochs", main = "", ylab = "Probability of Stable") + 
  theme(legend.position = "none") +
  theme_classic()

#DNN
dnn <- df2 %>% filter(model == 'DNN')
km <- with(dnn, Surv(time, status))
km_fit <- survfit(Surv(time, status) ~ 1, data=dnn)
#print the estimates for 1, 5, 10 and 15 days, and then every 15 epochs thereafter
summary(km_fit, times = c(1, 5, 10, 15*(1:10)))
autoplot(km_fit, xlab = "Epochs", main = "", ylab = "Probability of Stable") + 
  theme(legend.position = "none") +
  theme_classic()

# survival curves by treatment
km_trt_fit <- survfit(Surv(time, status) ~ ds, data=dnn)
autoplot(km_trt_fit, xlab = "Epochs", main = "", ylab = "Probability of Stable") + 
  theme(legend.position = "none") +
  theme_classic()

#3.2 Cox Proportional Hazards Model using the covariates----
cox <- coxph(Surv(time, status) ~ model + ds, data = df2)
summary(cox)
cox_fit <- survfit(cox)
#plot(cox_fit, main = "cph model", xlab="Days")
autoplot(cox_fit)

#showing how the effects of the covariates change over time
aa_fit <-aareg(Surv(time, status) ~ model + ds, data = df2) #takes a long time
aa_fit
autoplot(aa_fit)

#CNN
cnn <- df2 %>% filter(model == 'CNN')
km <- with(cnn, Surv(time, status))
km_fit <- survfit(Surv(time, status) ~ 1, data=cnn)
#print the estimates for 1, 5, 10 and 15 days, and then every 15 epochs thereafter
summary(km_fit, times = c(1, 5, 10, 15*(1:10)))
autoplot(km_fit, xlab = "Epochs", main = "", ylab = "Probability of Stable") + 
  theme(legend.position = "none") +
  theme_classic()

#3.3 tree-based modeling----
# ranger model
r_fit <- ranger(Surv(time, status) ~ model + ds,
                data = df2,
                mtry = 2,
                importance = "permutation",
                splitrule = "extratrees",
                verbose = TRUE)

# Average the survival models
death_times <- r_fit$unique.death.times 
surv_prob <- data.frame(r_fit$survival)
avg_prob <- sapply(surv_prob,mean)

# Plot the survival models for each node
plot(r_fit$unique.death.times,r_fit$survival[1,], #node 1
     type = "l", 
     ylim = c(0,1),
     col = "red",
     xlab = "Days",
     ylab = "survival",
     main = "Patient Survival Curves")

#
cols <- colors()
for (n in sample(c(2:dim(df2)[1]), 20)){
  lines(r_fit$unique.death.times, r_fit$survival[n,], type = "l", col = cols[n])
}
lines(death_times, avg_prob, lwd = 2)
legend(500, 0.7, legend = c('Average = black'))

vi <- data.frame(sort(round(r_fit$variable.importance, 4), decreasing = TRUE))
names(vi) <- "importance"
head(vi)

cat("Prediction Error = 1 - Harrell's c-index = ", r_fit$prediction.error)

## Prediction Error = 1 - Harrell's c-index =  0.3087233

# Set up for ggplot to compare all 3 methods above
kmi <- rep("KM",length(km_fit$time))
km_df <- data.frame(km_fit$time,km_fit$surv,kmi)
names(km_df) <- c("Time","Surv","Model")

coxi <- rep("Cox",length(cox_fit$time))
cox_df <- data.frame(cox_fit$time,cox_fit$surv,coxi)
names(cox_df) <- c("Time","Surv","Model")

rfi <- rep("RF",length(r_fit$unique.death.times))
rf_df <- data.frame(r_fit$unique.death.times,avg_prob,rfi)
names(rf_df) <- c("Time","Surv","Model")

plot_df <- rbind(km_df,cox_df,rf_df)

p <- ggplot(plot_df, aes(x = Time, y = Surv, color = Model))
p + geom_line(size = 1.1) +
theme_classic() +
  theme(axis.text.x = element_text(size = 30),
        axis.text.y = element_text(size = 30),
        axis.title.x = element_text(size = 30),
        axis.title.y = element_text(size = 30))

#old code ----
#Cox proportional hazzard model:
# cox <- coxph(Surv(time, node) ~ model + dataset + repl, data = df2)
# summary(cox)

#Survival by group
library(broom)
dfRes <- df %>% 
  group_by(model, dataset, repl) %>% 
  do(
    tidy(
      #lm(log(numstable+1) ~ epoch, data = .) #for ols; numstable~a*exp(r*epoch); pick r only
      glm(numstable ~ epoch, family = "poisson", data = .) #for Poisson regression; numstable~a*exp(r*epoch); pick r only
    )
  ) %>% 
  filter(term == 'epoch')
#do aov on the above dataframe
aov1 <- aov(estimate ~ model + dataset, 
            data = dfRes)
summary(aov1)
tukey1<-TukeyHSD(aov1)
tukey1

#Poisson regression (don't use b/c slope is IID, not Poisson distributed)
pois <- glm(estimate ~ model + dataset, family="poisson", data=dfRes)
summary(pois)

#plotting by group (need to filter for indiv plots)
dfPlot <- df %>% 
  group_by(model, dataset, epoch) %>% 
  summarise(meanNum = round(mean(numstable), 2),
            stdNum = round(sd(numstable), 3)) %>% 
  filter(model == 'CNN' &
           dataset == 'PR')
dfPlot  %>% ggplot(aes(epoch, meanNum)) +
  geom_point(size = 3) +
  #geom_jitter() +
  # stat_smooth(method = 'lm',
  #             formula = y ~ x + I(x^2),
  #             geom = 'smooth',
  #             size = 2, 
  #             fill='gray', 
  #             color='red') + 
  ylim(0, 1000) + 
  labs(x = "", 
       y = "") + 
  theme_classic() +
  theme(axis.text.x = element_text(size = 30),
        axis.text.y = element_text(size = 30),
        axis.title.y = element_text(size = 30))




