#phase 3 of thesis (pruning method comparisons; exp decay and tree label/value)

library(tidyverse)
#dfSimp <- read_csv("D:\\Dev\\Tree\\Data\\pruneData.csv")
dfSimp <- read_csv("D:\\Dev\\Tree\\Data\\pruneDatafl.csv")
dfSimp <- dfSimp %>% select(1:8)
totalNumNodes = 900
dfSimp <- dfSimp %>% mutate(perzeros = 100*nonzeroNode/totalNumNodes)
#if you want to look on this file using SQL Server
write.csv(dfSimp, "D:\\Dev\\Tree\\Data\\tosql.csv", row.names=FALSE)

dfg <- dfSimp %>% 
  group_by(model, dataset, method, repl) %>%
  summarise(mrt = mean(runtime),
            srt = sd(runtime)) %>%
  arrange(model, method, repl) %>% 
  ungroup()
write.csv(dfg, "D:\\Dev\\Tree\\Data\\summary2.csv", row.names=FALSE)

#positional stability
dftemp <- dfSimp %>% select(model, dataset, repl, prunedAcc, sparcity, nonzeroNode, perzeros, runtime, method) %>% 
                filter(model == 'cnn' & 
                         dataset == 'xr' &
                         (repl == 'r03' | repl == 'p01') &
                         prunedAcc > 0.0 &
                          (method == 'ed' | 
                            method == 'lbl')
)

dff <- dftemp %>% 
  group_by(model, dataset, method, perzeros) %>% 
  summarise(#pz = mean(perzeros),
            acc = sd(prunedAcc)) %>%
  arrange(model, dataset, method)

#dff %>% ggplot(aes(perzeros, acc, color = method)) +
dftemp %>% ggplot(aes(perzeros, prunedAcc, color = method)) +
  geom_point(aes(shape = method), size = 2) +
  # geom_line(aes(y=predReg), 
  #           size=2,
  #           color='red') +
  geom_line(aes(linetype = method), size = 1) +
  #geom_line(data = dplyr::filter(dff, class == "ed"), size = 3) +
  #geom_line(size = 3) +
  #geom_jitter() +
  # stat_smooth(aes(group=method),
  #             method = 'lm',
  #             formula = y ~ x + I(x^2) + I(x^3),
  #             geom = 'smooth',
  #             size = 1,
  #             #fill='gray',
  #             color='red') +
  #facet_grid(cols = vars(model), rows = vars(repl)) +
ylim(0, 1) + 
  xlim(0, 100) +
  labs(x = "", 
       y = "") + 
  theme_classic() +
  theme(axis.text.x = element_text(size = 15, color = 'black'),
        axis.text.y = element_text(size = 15, color = 'black'),
        axis.title.y = element_text(size = 15, color = 'black'),
        legend.text = element_text(size=20)) + 
  theme(legend.position = "none")




