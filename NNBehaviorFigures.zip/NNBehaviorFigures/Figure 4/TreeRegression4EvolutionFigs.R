#Tree investigation using regression depicting evolution of stable nodes
#through training

library('tidyverse')
library('broom')

LAYER <- 'theone'

#tree # stable nodes (AOV on num stable nodes and factors as below)----
dfReg <- read_csv(paste("D:\\Dev\\ThesisPy\\resultlog\\csv\\tree\\",
                     LAYER,"\\decTreeNumStableLabel.csv",
                     sep=''))
dfReg <- dfReg %>%
  mutate(dataset = replace(dataset, toupper(dataset) == 'M0', 'CT')) %>%   
  mutate(dataset = replace(dataset, toupper(dataset) == 'HW', 'PR'))

dfReg <- dfReg %>% filter(dataset != 'CT')

#regressions by group
library(broom)
dfRes <- dfReg %>% 
  group_by(model, dataset, repl) %>% 
  do(
    tidy(
      #lm(log(numstable+1) ~ epoch, data = .) #for ols; numstable~a*exp(r*epoch); pick r only
      glm(numstable ~ epoch, family = "poisson", data = .) #for Poisson regression; numstable~a*exp(r*epoch); pick r only
    )
  ) %>% 
  filter(term == 'epoch')
#do aov on the above dataframe
aov1 <- aov(estimate ~ model + dataset, 
            data = dfRes)
summary(aov1)
tukey1<-TukeyHSD(aov1)
tukey1

#Poisson regression (don't use b/c slope is IID, not Poisson distributed)
pois <- glm(estimate ~ model + dataset, family="poisson", data=dfRes)
summary(pois)

#plotting by group (need to filter for indiv plots)
dfPlot <- dfReg %>% 
  group_by(model, dataset, epoch) %>% 
  summarise(meanNum = round(mean(numstable), 2),
            stdNum = round(sd(numstable), 3)) %>% 
  filter(model == 'CNN' &
           dataset == 'PR')
dfPlot  %>% ggplot(aes(epoch, meanNum)) +
  geom_point(size = 3) +
  #geom_jitter() +
  # stat_smooth(method = 'lm',
  #             formula = y ~ x + I(x^2),
  #             geom = 'smooth',
  #             size = 2, 
  #             fill='gray', 
  #             color='red') + 
  ylim(0, 1000) + 
  labs(x = "", 
       y = "") + 
  theme_classic() +
  theme(axis.text.x = element_text(size = 30),
        axis.text.y = element_text(size = 30),
        axis.title.y = element_text(size = 30))




