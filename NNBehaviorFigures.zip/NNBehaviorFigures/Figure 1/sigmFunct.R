#generate the figure depicting how growth occurs in theory
library(tidyverse)
library(ggbump)
# dfSig <- data.frame(x = 1:6,
#                     y = 5:10,
#                     xend = 7,
#                     yend = -3:2)
dfSig <- data.frame(x = 0,
                    y = 0,
                    xend = 200,
                    yend = 1000)

dfSig %>% ggplot(aes(x = x, 
                     xend = xend, 
                     y = y, 
                     yend = yend)) +
  geom_sigmoid(size = 2,
               color = 'red') + 
  labs(x = "Epochs", 
       y = "Magnitude Stability") + 
  theme_classic() +
  theme(legend.position = "none") +
  theme(axis.text.x = element_text(size = 15),
        axis.text.y = element_text(size = 15),
        axis.title = element_text(size = 15))
